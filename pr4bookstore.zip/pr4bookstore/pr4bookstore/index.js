const fs = require('fs');
const path = require('path');
const multer = require('multer');
const express = require('express');

const db = require('./config/db');
const Books = require('./models/bookModel');

const PORT = 8000;
const app = express();


app.set('view engine', 'ejs');

app.use(express.urlencoded({ extended: true }));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use('/css', express.static(path.join(__dirname, 'public/css')));

const fileUpload = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads');
    },
    filename: (req, file, cb) => {
        cb(null, file.originalname);
    }
})
const imageUpload = multer({ storage: fileUpload }).single('avatar');

app.get('/', (req, res) => {
    Books.find({})
        .then((record) => {
            return res.render('pages/index', { record });
        }).catch((err) => {
            console.log(err);
            return false;
        })

})

app.get('/add', (req, res) => {
    return res.render('pages/form');
})

app.post('/addRecord', imageUpload, (req, res) => {
    const { title, author, page, genre, price, description } = req.body;
    if (!title || !author || !page || !genre || !price || !description || !req.file) {
        console.log("All field are required");
        return res.redirect('back');
    }
    Books.create({
        title, author, page, genre, price, description,
        image: req.file.path
    }).then((success) => {
        console.log("User successfully insert");
        return res.redirect('/')
    }).catch((err) => {
        console.log(err);
        return false;
    })
})

app.get('/deleteRecord', (req, res) => {
    let id = req.query.id;
    Books.findById(id)
        .then((oldRecord) => {
            fs.unlinkSync(oldRecord.image);
        }).catch((err) => {
            console.log(err);
            return false;
        })
        
    Books.findByIdAndDelete(id)
        .then((success) => {
            console.log("book delete");
            return res.redirect('back');
        }).catch((err) => {
            console.log(err);
            return false;
        })
})

app.get('/editRecord', (req, res) => {
    let id = req.query.id;
    Books.findById(id)
        .then((single) => {
            return res.render('pages/edit', {
                single
            })
        }).catch((err) => {
            console.log(err);
            return false;
        })
})

app.post('/updateRecord', imageUpload, (req, res) => {
    let id = req.body.editid;
    if (req.file) {
        Books.findById(id)
            .then((oldRecord) => {
                fs.unlinkSync(oldRecord.image)
            }).catch((err) => {
                console.log(err);
                return false;
            })

        Books.findByIdAndUpdate(id, {
            title: req.body.title,
            author: req.body.author,
            page: req.body.page,
            genre: req.body.genre,
            price: req.body.price,
            image:  req.file.path,
            description: req.body.description
        }).then((success) => {
            console.log("successfully edit");
            return res.redirect('/');
        }).catch((err) => {
            console.log(err);
            return false
        })
    } else {
        Books.findById(id)
            .then((oldRecord) => {
                Books.findByIdAndUpdate(id, {
                    title: req.body.title,
                    author: req.body.author,
                    page: req.body.page,
                    genre: req.body.genre,
                    price: req.body.price,
                    image: oldRecord.image,
                    description: req.body.description
                }).then((success) => {
                    console.log("successfully edit");
                    return res.redirect('/');
                }).catch((err) => {
                    console.log(err);
                    return false
                })
            }).catch((err) => {
                console.log(err);
                return false;
            })
    }
})

app.listen(PORT, (err) => {
    if (err) {
        console.log(`server is not start`);
        return false;
    }
    console.log(`server is  start on port :- http://localhost:${PORT}`);

})